// Chat functionality code here
