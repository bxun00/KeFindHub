
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import RegistrationForm from './components/RegistrationForm';
import FindMatches from './components/FindMatches';
import ChatRoom from './components/ChatRoom';
import SecurityReport from './components/SecurityReport';

function App() {
  const [search, setSearch] = useState('');

  return (
    <Router>
      <nav className="flex justify-center gap-4 p-4 bg-blue-600 text-white font-semibold">
        <Link to="/">Register</Link>
        <Link to="/find">Find Matches</Link>
        <Link to="/chat">Chat</Link>
        <Link to="/report">Security Report</Link>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search users..."
          className="rounded px-3 py-1 text-black ml-4"
        />
      </nav>
      <Routes>
        <Route path="/" element={<RegistrationForm />} />
        <Route path="/find" element={<FindMatches search={search} />} />
        <Route path="/chat" element={<ChatRoom />} />
        <Route path="/report" element={<SecurityReport />} />
      </Routes>
    </Router>
  );
}

export default App;
